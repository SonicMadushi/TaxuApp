class directionDetails{
  int distancevalue;
  int durationvalue;
  String distanceText;
  String durationText;
  String encodedPoints;
  directionDetails({this.distancevalue,this.durationvalue,this.distanceText,this.durationText,this.encodedPoints});
}