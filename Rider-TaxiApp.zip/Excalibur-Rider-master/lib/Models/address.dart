class Address{
  String placeFormattedAddress;
  String placeName;
  String placeId;
  double longitude;
  double latitude;
  Address({this.placeFormattedAddress,this.placeName
  ,this.placeId,this.longitude,this.latitude
  });

}